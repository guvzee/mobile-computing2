//
//  ViewController.swift
//  calculator app for pre school
//
//  Created by gd13aaf on 20/03/2017.
//  Copyright © 2017 gd13aaf. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var QuestionLabel: UILabel!
   
    @IBOutlet weak var btn0: UIButton!
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var btn3: UIButton!
    
    @IBOutlet weak var btn4: UIButton!
    
    @IBOutlet weak var btn5: UIButton!
    
    @IBOutlet weak var btn6: UIButton!
    
    @IBOutlet weak var btn7: UIButton!
    
    @IBOutlet weak var btn8: UIButton!
    
    @IBOutlet weak var btn9: UIButton!
    
    var CorrectAnswer = String()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func RandomQuestions(){
        
        var RandomNumber = arc4random() % 10
        RandomNumber += 1
        
        switch(RandomNumber){
            
            
        
            
        
            
        case 1:
            
            QuestionLabel.text = "What is 3 + 2? "
            CorrectAnswer = "5"
            break
        case 2:
            
            QuestionLabel.text =  "What is 4 + 4?"
            CorrectAnswer = "8"
            break
            
        case 3:
            QuestionLabel.text = "What is 1 + 6?"
            CorrectAnswer = "7"
            
            break
            
        case 4:
            QuestionLabel.text = "What is 7 + 2?"
            CorrectAnswer = "9"
            break
            
        case 5:
            QuestionLabel.text = " what is 1 + 1 "
            CorrectAnswer = "2"
            break
            
        case 6:
            QuestionLabel.text = " what is 2 + 2?"
            CorrectAnswer = "4"
            break
            
        case 7:
            QuestionLabel.text = "what is 3 + 3?"
            CorrectAnswer = "6"
            break
            
        case 8:
            QuestionLabel.text = "What is 4 + 3? "
            CorrectAnswer = "7"
            break
            
        case 9:
            QuestionLabel.text = "what is 3 + 6? "
            CorrectAnswer = "9"
            break
        case 10:
            QuestionLabel.text = " what is 4 + 1"
            CorrectAnswer = "5"
            break
            
        
        default:
            
            break
        
            
        }
        
        
    }

    @IBAction func btnn0(sender: AnyObject) {
        if (CorrectAnswer == "0"){
            NSLog("you are correct!")
            
        }
        else{
            NSLog("you are wrong!!")
        }
    
    }
    @IBAction func btnn1(sender: AnyObject) {
        if (CorrectAnswer == "1"){
            NSLog("you are correct")
        }
        else{
            NSLog("you are wrong!!")
        }
        
    }
    @IBAction func btnn2(sender: AnyObject) {
        if (CorrectAnswer == "2"){
            NSLog("you are correct ")
        }
        else{
            NSLog("you are wrong!!")
        }
    }
    @IBAction func btnn3(sender: AnyObject) {
        if(CorrectAnswer == "3"){
            NSLog("you are correct")
            
        }
        else{
            NSLog("you are wrong!!")
        }
    }
    @IBAction func btnn4(sender: AnyObject) {
        if(CorrectAnswer == "4"){
            NSLog("you are correct" )
        }
    }
    @IBAction func btnn5(sender: AnyObject) {
        if(CorrectAnswer == "5") {
            NSLog("you are correct" )
        }
    }
    @IBAction func btnn6(sender: AnyObject) {
        if(CorrectAnswer == "6") {
            NSLog("you are correct")
        }
        else{
            NSLog("you are wrong!!")
        }
    }
    @IBAction func btnn7(sender: AnyObject) {
        if(CorrectAnswer == "7") {
            NSLog("you are correct")
            
        }
        else{
            NSLog("you are wrong!!")
            
        }
            
    }
    @IBAction func btnn8(sender: AnyObject) {
        if(CorrectAnswer == "8"){
            NSLog("you are correct ")
        }
        else{
            NSLog("you are wrong!!")
        }
        
    }
    @IBAction func btnn9(sender: AnyObject) {
        if(CorrectAnswer == "9"){
            NSLog("you are correct")
        }
        else{
            NSLog("you are wrong!!")
        }
    }

}

